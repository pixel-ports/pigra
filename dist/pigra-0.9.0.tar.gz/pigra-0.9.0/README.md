The Python IGRAv2 parsing library
=================================

**pigra** 
- parses IGRA data according to the [IGRAv2 specifications](ftp://ftp.ncdc.noaa.gov/pub/data/igra/data/igra2-data-format.txt)
- defines a clean Sounding data-structure easy to work with
- processes records on the fly without storing the whole archive in memory
- allows to filter soundings by providing your own function
- handles output to json format or human-readable headers
- computes statistics
- unit-tested


Getting started
---------------

### A simple example
This example processes one hour of ISH surface from the NOAA FTP server for the weather station Thessaloniki.

![noaafwragent example](example.gif)

Install
-------

Clone the git repository.
```
$ git clone https://gitpixel.satrdlab.upv.es/fabien.battello/data-acquisition.git
```

pyngsi requires Python 3.8+. Make sure it's installed on your system.

```bash
$ which python3.8
/usr/bin/python3.8
```

The recommanded way is to use a virtual environment.

```bash
$ mkdir pixel-dal
$ cd pixel-dal
$ python3.8 -m venv venv
$ source venv/bin/activate
```

First install dependencies, especially the pyngsi library.
```bash
$ pip install --find-links ../pyngsi/dist -r requirements.txt
```

Then install the NOAA agent, from the directory noaafwragent/dist.
```bash
$ pip install noaafwragent-0.9.0.tar.gz
```

**noaafwrcli** is automatically added to your PATH.<br>
Check the agent is correctly installed.
```console
$ noaafwrcli --version
noaafwrcli, version 0.9.0
```

How do I use noaafwragent ?
---------------------------
**noaafwragent** is a Python library that comes with its CLI **noaafwrcli**.

So you can either weather station data from your Python code or directly from a shell.

CLI Usage
-----
You can use the CLI directly from a shell.<br>
For further information, please use ``noaafwrcli --help``.

<u>Example 1</u>

This example processes one hour of ISH surface from the NOAA FTP server for the weather station Thessaloniki.

```console
$ noaafwrcli -vv --usaf=166220 --sink-orion 127.0.0.1 1026 --date-start=2018 --date-end=2018-01-01T01:00
```

You already know this example, but this time the agent outputs to a Fiware Orion server, instead of the standard output.<br>
For testing purpose, one could use the ``docker-compose`` file provided in the directory pixel-docker.<br>

When wban is not specified, it defaults to 99999.<br>
The start date if not complete aligns with the smallest date.<br>
The end date if not complete aligns with the highest date.<br>

In this example, just one file is needed from the FTP server.<br>
It is retrieved in a temporary directory, processed, and removed at the end.<br>
As we take only one hour, the rest of the record are not processed. This is reported in the statistics (filtered).

<u>Example 2</u>

This example processes three years of ISH surface from the NOAA FTP server for the weather station Thessaloniki.

```console
$ noaafwrcli -vv --usaf=166220 --sink-orion 127.0.0.1 1026 --date-start=2016 --date-end=2018
```

This time the agent retrieves 3 files from the NOAA FTP server.
This is completly hidden from the user point of view.


Orion Sink
----------
**noaafwragent** sends its output to the Orion Context Broker, which is part of the Fiware platform.<br>


The `orion` sink allows to set the `Fiware-ServicePath` HTTP header according to the `--fiware-service-path` option.

`orion` is an asynchronous sink, meaning that the Agent won't be blocked while the sink is busy at dealing with network IO.


<u>Example :</u>
```console
$ noaafwrcli --sink-orion 127.0.0.1 1026
```

Status
------
Version 0.9.0 is still beta.<br>
Please send feedback : create issues or just discuss in Pixel meetings.

Contributing
------------
Submit pull requests.

Build
-----
Prerequisite : setuptools installed.<br>
```bash
$ python -m pip install --upgrade pip setuptools wheel
```

To install locally :
```bash
$ pip install --editable .
```

To install a distributable package :
```python
python setup.py sdist bdist_wheel
```

To change the version number, 2 files must be updated : ``setup.py`` and ``__init__.py``.

Docker
------
Build the docker image :
```bash
$ docker build -t noaafwragent:1.0 .
```

Run the docker container :
```bash
$ docker run --name noaafwragent noaafwragent:1.0 -vv --usaf=166220 --sink-stdout --date-start=2018 --date-end=2018-01-01T01:00
```

License
--------

    Copyright (C) 2019 Orange

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.